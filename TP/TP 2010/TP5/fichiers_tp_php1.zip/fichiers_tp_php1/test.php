<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

  <meta content="text/html; charset=UTF-8" http-equiv="content-type" />
  <title>Test PHP</title>


</head>

<body>

<h2>Premier test PHP</h2>

<p>
<?php 
$n=7; $d=3; 
echo "$n/$d egale : " . ($n/$d) ."<br />"; 
?>
</p>

</body>

</html>
